#! python3

from . import console_init

console_init()
